# coding = utf-8

EXCEL_DIR="C:\\Users\\Lenovo\\Desktop\\yidongceshi\\demo\\demo\\data\\search_query.xlsx"
